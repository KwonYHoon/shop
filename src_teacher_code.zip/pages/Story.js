import "../css/story.css";

export default function Story() {
  return (
    <main className="mw story">
      <h2>회사소개</h2>
      <p>내용이 들어갑니다.</p>
    </main>
  );
}
