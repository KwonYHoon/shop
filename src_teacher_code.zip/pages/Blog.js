import "../css/blog.css";

export default function Blog({ movieList }) {
  console.log(movieList);
  return (
    <main className="mw blog">
      <h2>영화리스트</h2>
      <ul className="movielist">
        {movieList.map((list, i) => {
          return (
            <li key={i}>
              <p>영화제목 :{list.movieNm}</p>
              <p>개봉일 :{list.openDt}</p>
            </li>
          );
        })}
      </ul>
    </main>
  );
}
