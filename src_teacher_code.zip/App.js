import "./App.css";
import Header from "./common/Header";
import Footer from "./common/Footer";
import Main from "./pages/Main";
import Shop from "./pages/Shop";
import Detail from "./pages/Detail";
import Blog from "./pages/Blog";
import Story from "./pages/Story";
import { Route, Routes } from "react-router-dom";
import list from "./productData";
import { useEffect, useState } from "react";

function App() {
  let [movieList, setMovieList] = useState([]);
  let [result, setResult] = useState([]);

  useEffect(() => {
    fetch(
      "https://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=4bc765582315616d174fd80c60016295&targetDt=20230916"
    )
      .then((res) => res.json())
      .then((res) => setMovieList(res.boxOfficeResult.dailyBoxOfficeList));

    // 문화체육 관관부 api - 관광지URL 설정
    const apiUrl =
      "http://api.kcisa.kr/openapi/API_CNV_060/request?serviceKey=1d680009-0b7a-432a-bfc7-2ac27400a79c&numOfRows=100&pageNo=1";

    // Fetch API를 사용하여 XML 데이터 가져오기
    fetch(apiUrl)
      .then((response) => response.text())
      .then((xmlData) => {
        // 가져온 XML 데이터를 JSON으로 변환
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlData, "text/xml");

        // XML 데이터를 JSON으로 변환하는 함수 호출
        const jsonData = xmlToJson(xmlDoc);

        // jsonData를 사용하여 원하는 작업 수행
        // console.log(jsonData);
        setResult(jsonData.response.body.items.item);
      })
      .catch((error) => {
        console.error("데이터 가져오기 실패:", error);
      });

    // XML을 JSON으로 변환하는 함수
    function xmlToJson(xml) {
      let result = {};

      if (xml.nodeType === Node.ELEMENT_NODE) {
        if (xml.attributes.length > 0) {
          result["@attributes"] = {};
          for (let i = 0; i < xml.attributes.length; i++) {
            const attribute = xml.attributes[i];
            result["@attributes"][attribute.nodeName] = attribute.nodeValue;
          }
        }
      } else if (xml.nodeType === Node.TEXT_NODE) {
        result = xml.nodeValue;
      }

      if (xml.hasChildNodes()) {
        for (let i = 0; i < xml.childNodes.length; i++) {
          const child = xml.childNodes[i];
          const childData = xmlToJson(child);

          if (Array.isArray(result[child.nodeName])) {
            result[child.nodeName].push(childData);
          } else if (result[child.nodeName]) {
            result[child.nodeName] = [result[child.nodeName], childData];
          } else {
            result[child.nodeName] = childData;
          }
        }
      }

      return result;
    }
  }, []);
  // console.log(result);
  return (
    <div className="App">
      <Header />
      <Routes>
        <Route path="/" element={<Main list={list} />} />
        <Route path="/shop" element={<Shop list={list} />} />
        <Route path="/blog" element={<Blog movieList={movieList} />} />
        <Route path="/story" element={<Story />} />
        <Route path="/detail/:id" element={<Detail list={list} />} />
        <Route path="*" element={<>이런 페이지는 없소 404 </>} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
