const parse = () => {};

export default parse;
