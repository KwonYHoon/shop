import "./App.css";
import "./css/shop.css";

import Header from "./common/Header";
import Footer from "./common/Footer";
import Banner from "./common/Banner";
import MainList from "./common/MainList";
import Shop from "./pages/Shop";

function App() {
  return (
    <div className="App">
      <Header />
      {/* <main>
        <Banner />
        <MainList />
      </main> */}
      <Shop/>
      <Footer />
    </div>
  );
}

export default App;
