import Card from "../common/Card";

export default function Shop() {
    return (
      <main className="Shop mw">
        <h1>All Goods</h1>
        <div className="AllList">
          <nav className="ShopBtnWrap">
            <button className="btn">등록순</button>
            <button className="btn">낮은 가격</button>
            <button className="btn">높은 가격</button>
            <button className="btn">높은 할인율</button>
          </nav>
          <ul className="__list">
            <li>
              <Card />
            </li>
          </ul>
        </div>
      </main>
    );
  }