export default function Footer() {
  return (
    <>
      <h1>하단영역</h1>
    </>
  );
}
