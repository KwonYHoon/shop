export default function Header() {
  return (
    <header className="mw">
      <h1>
        <img src="/img/logo.svg" alt="쇼핑몰로고" />
      </h1>
      <nav>
        <a href="#">shop</a>
        <a href="#">bolg</a>
        <a href="#">our story</a>
      </nav>
      <div>
        <a href="#">
          <i className="fa-solid fa-magnifying-glass"></i>
        </a>
        <a href="#">
          <i className="fa-solid fa-cart-arrow-down"></i>
        </a>
        <a href="#">
          <i className="fa-solid fa-person"></i>
        </a>
      </div>
    </header>
  );
}
